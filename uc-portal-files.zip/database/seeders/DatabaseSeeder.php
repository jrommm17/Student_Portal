<?php

namespace Database\Seeders;

use App\Models\Announcement;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $pw = 'password123';

        $admin = User::create(['school_id' => 'ADMIN-001', 'name' => 'Registrar Office', 'email' => 'admin@uc-demo.test', 'role' => 'admin', 'program' => 'Office of the Registrar', 'password' => $pw]);
        $ins1  = User::create(['school_id' => 'INS-001', 'name' => 'Prof. Maria Santos', 'email' => 'msantos@uc-demo.test', 'role' => 'instructor', 'program' => 'College of Information Technology', 'password' => $pw]);
        $ins2  = User::create(['school_id' => 'INS-002', 'name' => 'Prof. Ramon Dizon', 'email' => 'rdizon@uc-demo.test', 'role' => 'instructor', 'program' => 'College of Information Technology', 'password' => $pw]);

        $students = collect([
            ['2023-00101', 'Juan Dela Cruz', 'juan@uc-demo.test'],
            ['2023-00102', 'Ana Reyes', 'ana@uc-demo.test'],
            ['2023-00103', 'Mark Villanueva', 'mark@uc-demo.test'],
        ])->map(fn ($s) => User::create(['school_id' => $s[0], 'name' => $s[1], 'email' => $s[2], 'role' => 'student', 'program' => 'BSIT', 'password' => $pw]));

        $subjects = collect([
            ['IT 301', 'Web Systems and Technologies', 3, 'MWF 8:00-9:00 AM', 'Room 305', $ins1],
            ['IT 302', 'Database Management Systems', 3, 'TTh 9:00-10:30 AM', 'Computer Lab 2', $ins1],
            ['IT 303', 'Systems Analysis and Design', 3, 'MWF 10:00-11:00 AM', 'Room 210', $ins2],
            ['IT 304', 'Information Assurance and Security', 3, 'TTh 1:00-2:30 PM', 'Room 212', $ins2],
            ['GE 105', 'Ethics', 3, 'Sat 8:00-11:00 AM', 'Room 101', null],
        ])->map(fn ($s) => Subject::create(['code' => $s[0], 'title' => $s[1], 'units' => $s[2], 'schedule' => $s[3], 'room' => $s[4], 'instructor_id' => $s[5]?->id]));

        foreach ($students as $i => $student) {
            foreach ($subjects->take(4)->values() as $j => $subject) {
                $grade = $i === 0 ? ['1.50', '1.75', null, null][$j] : null;
                $student->enrolledSubjects()->attach($subject->id, ['grade' => $grade]);
            }
        }

        Announcement::create(['author_id' => $admin->id, 'title' => 'Welcome to the Student Portal', 'body' => 'Log in with your school ID or email. Contact the Registrar if you cannot access your account.', 'audience' => 'all']);
        Announcement::create(['author_id' => $admin->id, 'title' => 'Grade submission reminder', 'body' => 'Instructors, please encode midterm grades through My Classes before the deadline.', 'audience' => 'instructor']);
    }
}
