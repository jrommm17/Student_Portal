<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\InstructorController;
use App\Http\Controllers\StudentController;
use App\Http\Middleware\RoleMiddleware;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/login');

Route::middleware('guest')->group(function () {
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:6,1')->name('login.store');
});

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::middleware(RoleMiddleware::class . ':student')->prefix('student')->name('student.')->group(function () {
        Route::get('subjects', [StudentController::class, 'subjects'])->name('subjects');
        Route::post('subjects/{subject}/enroll', [StudentController::class, 'enroll'])->name('enroll');
        Route::delete('subjects/{subject}/drop', [StudentController::class, 'drop'])->name('drop');
        Route::get('grades', [StudentController::class, 'grades'])->name('grades');
    });

    Route::middleware(RoleMiddleware::class . ':instructor')->prefix('instructor')->name('instructor.')->group(function () {
        Route::get('classes', [InstructorController::class, 'classes'])->name('classes');
        Route::get('classes/{subject}', [InstructorController::class, 'show'])->name('class');
        Route::post('classes/{subject}/grades', [InstructorController::class, 'saveGrades'])->name('grades');
    });

    Route::middleware(RoleMiddleware::class . ':admin')->prefix('admin')->name('admin.')->group(function () {
        Route::get('users', [AdminController::class, 'users'])->name('users');
        Route::post('users', [AdminController::class, 'storeUser'])->name('users.store');
        Route::delete('users/{user}', [AdminController::class, 'destroyUser'])->name('users.destroy');

        Route::get('subjects', [AdminController::class, 'subjects'])->name('subjects');
        Route::post('subjects', [AdminController::class, 'storeSubject'])->name('subjects.store');
        Route::patch('subjects/{subject}', [AdminController::class, 'assignInstructor'])->name('subjects.assign');
        Route::delete('subjects/{subject}', [AdminController::class, 'destroySubject'])->name('subjects.destroy');

        Route::get('announcements', [AdminController::class, 'announcements'])->name('announcements');
        Route::post('announcements', [AdminController::class, 'storeAnnouncement'])->name('announcements.store');
        Route::delete('announcements/{announcement}', [AdminController::class, 'destroyAnnouncement'])->name('announcements.destroy');
    });
});
