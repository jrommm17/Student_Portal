@extends('layouts.app')
@section('title', 'Dashboard')
@section('heading', 'Administration')

@section('content')
  <h2 class="page-title">Registrar overview</h2>
  <p class="muted">Accounts, subjects, and announcements for the whole portal.</p>

  <div class="strip">
    @foreach ($counts as $label => $n)
      <div><span>{{ $label }}</span><strong>{{ $n }}</strong></div>
    @endforeach
  </div>

  <div class="row g-4">
    <div class="col-xl-8">
      <section class="panel">
        <h3>Manage</h3>
        <div class="quick">
          <a href="{{ route('admin.users') }}"><i class="bi bi-people"></i><span>Users<small>Add instructors, view students</small></span></a>
          <a href="{{ route('admin.subjects') }}"><i class="bi bi-journal-text"></i><span>Subjects<small>Create subjects and assign instructors</small></span></a>
          <a href="{{ route('admin.announcements') }}"><i class="bi bi-megaphone"></i><span>Announcements<small>Post notices by audience</small></span></a>
        </div>
      </section>
    </div>
    <div class="col-xl-4">@include('partials.announcements')</div>
  </div>
@endsection
