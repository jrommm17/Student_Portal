@extends('layouts.app')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')

@section('content')
  <h2 class="page-title">Good day, {{ strtok(auth()->user()->name, ' ') }}.</h2>
  <p class="muted">{{ auth()->user()->program }} student, {{ auth()->user()->school_id }}</p>

  <div class="strip">
    <div><span>Subjects enrolled</span><strong>{{ $subjects->count() }}</strong></div>
    <div><span>Total units</span><strong>{{ $subjects->sum('units') }}</strong></div>
    <div><span>General weighted average</span><strong>{{ $gwa ? number_format($gwa, 2) : 'None yet' }}</strong></div>
  </div>

  <div class="row g-4">
    <div class="col-xl-8">
      <section class="panel">
        <h3>My schedule</h3>
        @if ($subjects->isEmpty())
          <p class="empty">You are not enrolled in any subject yet. <a href="{{ route('student.subjects') }}" class="link-uc">Browse subjects</a> to enroll.</p>
        @else
          <div class="table-responsive">
            <table class="table table-uc">
              <thead><tr><th>Code</th><th>Subject</th><th>Schedule</th><th>Room</th><th>Instructor</th></tr></thead>
              <tbody>
              @foreach ($subjects as $s)
                <tr><td>{{ $s->code }}</td><td>{{ $s->title }}</td><td>{{ $s->schedule ?? 'To be announced' }}</td><td>{{ $s->room ?? 'TBA' }}</td><td>{{ $s->instructor->name ?? 'Unassigned' }}</td></tr>
              @endforeach
              </tbody>
            </table>
          </div>
        @endif
      </section>
    </div>
    <div class="col-xl-4">@include('partials.announcements')</div>
  </div>
@endsection
