@extends('layouts.app')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')

@section('content')
  <h2 class="page-title">Good day, {{ auth()->user()->name }}.</h2>
  <p class="muted">{{ auth()->user()->program }}</p>

  <div class="strip">
    <div><span>Classes handled</span><strong>{{ $classes->count() }}</strong></div>
    <div><span>Students across classes</span><strong>{{ $totalStudents }}</strong></div>
  </div>

  <div class="row g-4">
    <div class="col-xl-8">
      <section class="panel">
        <h3>My classes</h3>
        @if ($classes->isEmpty())
          <p class="empty">No class is assigned to you yet. Ask the Registrar to assign one.</p>
        @else
          <div class="table-responsive">
            <table class="table table-uc">
              <thead><tr><th>Code</th><th>Subject</th><th>Schedule</th><th>Students</th><th></th></tr></thead>
              <tbody>
              @foreach ($classes as $c)
                <tr><td>{{ $c->code }}</td><td>{{ $c->title }}</td><td>{{ $c->schedule ?? 'TBA' }}</td><td>{{ $c->students_count }}</td>
                    <td class="text-end"><a href="{{ route('instructor.class', $c) }}" class="btn btn-uc-outline btn-sm">Open class</a></td></tr>
              @endforeach
              </tbody>
            </table>
          </div>
        @endif
      </section>
    </div>
    <div class="col-xl-4">@include('partials.announcements')</div>
  </div>
@endsection
