<section class="panel">
  <h3>Announcements</h3>
  @forelse ($announcements as $a)
    <article class="note">
      <h4>{{ $a->title }}</h4>
      <p>{{ $a->body }}</p>
      <small>{{ $a->author->name }}, {{ $a->created_at->format('M d, Y') }}</small>
    </article>
  @empty
    <p class="empty">No announcements right now.</p>
  @endforelse
</section>
