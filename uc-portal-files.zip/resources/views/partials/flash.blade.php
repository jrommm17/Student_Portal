@if (session('status'))
  <div class="notice notice-ok" role="status"><i class="bi bi-check-circle-fill"></i> {{ session('status') }}</div>
@endif
@if ($errors->any() && ! request()->routeIs('login', 'register'))
  <div class="notice notice-err" role="alert">
    <i class="bi bi-exclamation-triangle-fill"></i>
    <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
  </div>
@endif
