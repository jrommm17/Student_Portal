@php $size = $size ?? 56; @endphp
@if (file_exists(public_path('images/uc-logo.png')))
  <img src="{{ asset('images/uc-logo.png') }}" alt="University of the Cordilleras Philippines logo" width="{{ $size }}" height="{{ $size }}" class="crest">
@else
  {{-- Placeholder crest. Put the official logo at public/images/uc-logo.png to replace it. --}}
  <svg class="crest" width="{{ $size }}" height="{{ $size }}" viewBox="0 0 64 72" role="img" aria-label="School crest">
    <path d="M32 3 59 12v24c0 16-12 27-27 33C17 63 5 52 5 36V12Z" fill="#1f5b3a" stroke="#c9a24a" stroke-width="3"/>
    <path d="m32 15 10 15h-5l8 12h-7l8 12H18l8-12h-7l8-12h-5Z" fill="#f4f6f2"/>
    <rect x="30" y="54" width="4" height="7" fill="#c9a24a"/>
  </svg>
@endif
