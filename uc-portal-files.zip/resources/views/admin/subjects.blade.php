@extends('layouts.app')
@section('title', 'Subjects')
@section('heading', 'Subjects')

@section('content')
  <section class="panel">
    <h3>Add a subject</h3>
    <form method="POST" action="{{ route('admin.subjects.store') }}" class="row g-3">
      @csrf
      <div class="col-md-2"><label class="form-label">Code</label><input name="code" value="{{ old('code') }}" class="form-control" placeholder="IT 305" required></div>
      <div class="col-md-6"><label class="form-label">Title</label><input name="title" value="{{ old('title') }}" class="form-control" required></div>
      <div class="col-md-2"><label class="form-label">Units</label><input type="number" name="units" min="1" max="6" value="{{ old('units', 3) }}" class="form-control" required></div>
      <div class="col-md-2"><label class="form-label">Room</label><input name="room" value="{{ old('room') }}" class="form-control"></div>
      <div class="col-md-5"><label class="form-label">Schedule</label><input name="schedule" value="{{ old('schedule') }}" class="form-control" placeholder="MWF 8:00-9:00 AM"></div>
      <div class="col-md-5">
        <label class="form-label">Instructor</label>
        <select name="instructor_id" class="form-select">
          <option value="">Assign later</option>
          @foreach ($instructors as $i)<option value="{{ $i->id }}" @selected((string) old('instructor_id') === (string) $i->id)>{{ $i->name }}</option>@endforeach
        </select>
      </div>
      <div class="col-md-2 d-flex align-items-end"><button class="btn btn-uc w-100">Add subject</button></div>
    </form>
  </section>

  <section class="panel">
    <h3>All subjects ({{ $subjects->count() }})</h3>
    <div class="table-responsive">
      <table class="table table-uc align-middle">
        <thead><tr><th>Code</th><th>Subject</th><th>Units</th><th>Students</th><th style="min-width:280px">Instructor</th><th></th></tr></thead>
        <tbody>
        @foreach ($subjects as $s)
          <tr>
            <td>{{ $s->code }}</td><td>{{ $s->title }}<br><small class="muted">{{ $s->schedule ?? 'No schedule' }}</small></td>
            <td>{{ $s->units }}</td><td>{{ $s->students_count }}</td>
            <td>
              <form method="POST" action="{{ route('admin.subjects.assign', $s) }}" class="d-flex gap-2">
                @csrf @method('PATCH')
                <select name="instructor_id" class="form-select form-select-sm">
                  <option value="">Unassigned</option>
                  @foreach ($instructors as $i)<option value="{{ $i->id }}" @selected($s->instructor_id === $i->id)>{{ $i->name }}</option>@endforeach
                </select>
                <button class="btn btn-uc-outline btn-sm">Save</button>
              </form>
            </td>
            <td class="text-end">
              <form method="POST" action="{{ route('admin.subjects.destroy', $s) }}" onsubmit="return confirm('Delete {{ $s->code }}? Enrollments and grades for it will be removed.')">
                @csrf @method('DELETE') <button class="btn btn-danger-soft btn-sm">Delete</button>
              </form>
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </section>
@endsection
