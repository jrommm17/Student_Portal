@extends('layouts.app')
@section('title', 'Announcements')
@section('heading', 'Announcements')

@section('content')
  <section class="panel">
    <h3>Post an announcement</h3>
    <form method="POST" action="{{ route('admin.announcements.store') }}" class="row g-3">
      @csrf
      <div class="col-md-8"><label class="form-label">Title</label><input name="title" value="{{ old('title') }}" class="form-control" required></div>
      <div class="col-md-4">
        <label class="form-label">Who should see it</label>
        <select name="audience" class="form-select">
          <option value="all">Everyone</option>
          <option value="student">Students only</option>
          <option value="instructor">Instructors only</option>
        </select>
      </div>
      <div class="col-12"><label class="form-label">Message</label><textarea name="body" rows="3" class="form-control" required>{{ old('body') }}</textarea></div>
      <div class="col-12"><button class="btn btn-uc">Post announcement</button></div>
    </form>
  </section>

  <section class="panel">
    <h3>Posted announcements</h3>
    @forelse ($announcements as $a)
      <article class="note d-flex justify-content-between gap-3">
        <div>
          <h4>{{ $a->title }} <span class="tag">{{ $a->audience === 'all' ? 'Everyone' : ucfirst($a->audience) . 's' }}</span></h4>
          <p>{{ $a->body }}</p>
          <small>{{ $a->author->name }}, {{ $a->created_at->format('M d, Y g:i A') }}</small>
        </div>
        <form method="POST" action="{{ route('admin.announcements.destroy', $a) }}" onsubmit="return confirm('Delete this announcement?')">
          @csrf @method('DELETE') <button class="btn btn-danger-soft btn-sm">Delete</button>
        </form>
      </article>
    @empty
      <p class="empty">Nothing posted yet. Use the form above to post the first announcement.</p>
    @endforelse
  </section>
@endsection
