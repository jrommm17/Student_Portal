@extends('layouts.app')
@section('title', 'Users')
@section('heading', 'Users')

@section('content')
  <section class="panel">
    <h3>Add an account</h3>
    <form method="POST" action="{{ route('admin.users.store') }}" class="row g-3">
      @csrf
      <div class="col-md-3"><label class="form-label">School ID</label><input name="school_id" value="{{ old('school_id') }}" class="form-control" required></div>
      <div class="col-md-5"><label class="form-label">Full name</label><input name="name" value="{{ old('name') }}" class="form-control" required></div>
      <div class="col-md-4"><label class="form-label">Email</label><input type="email" name="email" value="{{ old('email') }}" class="form-control" required></div>
      <div class="col-md-3">
        <label class="form-label">Role</label>
        <select name="role" class="form-select" required>
          <option value="instructor" @selected(old('role', 'instructor') === 'instructor')>Instructor</option>
          <option value="student" @selected(old('role') === 'student')>Student</option>
          <option value="admin" @selected(old('role') === 'admin')>Administrator</option>
        </select>
      </div>
      <div class="col-md-5"><label class="form-label">Program or department</label><input name="program" value="{{ old('program') }}" class="form-control" placeholder="BSIT or College of Information Technology"></div>
      <div class="col-md-4"><label class="form-label">Temporary password</label><input type="password" name="password" class="form-control" placeholder="At least 8 characters" required></div>
      <div class="col-12"><button class="btn btn-uc">Create account</button></div>
    </form>
  </section>

  <section class="panel">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
      <h3 class="mb-0">All users ({{ $users->count() }})</h3>
      <div class="filters">
        <a href="{{ route('admin.users') }}" class="{{ ! $role ? 'on' : '' }}">All</a>
        <a href="{{ route('admin.users', ['role' => 'student']) }}" class="{{ $role === 'student' ? 'on' : '' }}">Students</a>
        <a href="{{ route('admin.users', ['role' => 'instructor']) }}" class="{{ $role === 'instructor' ? 'on' : '' }}">Instructors</a>
        <a href="{{ route('admin.users', ['role' => 'admin']) }}" class="{{ $role === 'admin' ? 'on' : '' }}">Admins</a>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-uc">
        <thead><tr><th>School ID</th><th>Name</th><th>Email</th><th>Role</th><th>Program or department</th><th></th></tr></thead>
        <tbody>
        @foreach ($users as $u)
          <tr>
            <td>{{ $u->school_id }}</td><td>{{ $u->name }}</td><td>{{ $u->email }}</td>
            <td><span class="tag">{{ ucfirst($u->role) }}</span></td><td>{{ $u->program }}</td>
            <td class="text-end">
              @if ($u->id !== auth()->id())
                <form method="POST" action="{{ route('admin.users.destroy', $u) }}" onsubmit="return confirm('Delete {{ $u->name }}? This also removes their enrollments.')">
                  @csrf @method('DELETE') <button class="btn btn-danger-soft btn-sm">Delete</button>
                </form>
              @endif
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </section>
@endsection
