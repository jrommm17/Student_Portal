<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title') | University of the Cordilleras Philippines</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600&family=Source+Serif+4:opsz,wght@8..60,500;8..60,700&display=swap" rel="stylesheet">
  <link href="{{ asset('css/portal.css') }}" rel="stylesheet">
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
  <div class="auth">
    <aside class="auth-art">
      <div class="auth-art-body">
        @include('partials.crest', ['size' => 88])
        <h1>University of the Cordilleras<br>Philippines</h1>
        <p class="sub">Student Portal</p>
        <p class="lede">Sign in with your school ID or email. Students, instructors, and administrators all enter here.</p>
      </div>
      <svg class="ridge" viewBox="0 0 800 200" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0 200V120L90 60l80 50 90-80 100 90 90-50 110 60 100-80 140 70v60Z" fill="rgba(255,255,255,.06)"/>
        <path d="M0 200v-40l120-50 110 50 110-60 130 65 120-50 120 45 90-30v70Z" fill="rgba(255,255,255,.09)"/>
      </svg>
    </aside>

    <main class="auth-form">
      <div class="auth-box">
        <div class="auth-mobile-brand">@include('partials.crest', ['size' => 40]) <strong>University of the Cordilleras Philippines</strong></div>
        @include('partials.flash')
        @yield('content')
      </div>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.querySelectorAll('.btn-eye').forEach(btn => btn.addEventListener('click', () => {
      const input = document.querySelector(btn.dataset.target);
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.querySelector('i').className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
    }));
    document.querySelectorAll('form.js-loading').forEach(form => form.addEventListener('submit', () => {
      const b = form.querySelector('button[type=submit]');
      b.disabled = true;
      b.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Please wait';
    }));
  </script>
</body>
</html>
