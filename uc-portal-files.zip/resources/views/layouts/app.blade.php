<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title') | University of the Cordilleras Philippines</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600&family=Source+Serif+4:opsz,wght@8..60,500;8..60,700&display=swap" rel="stylesheet">
  <link href="{{ asset('css/portal.css') }}" rel="stylesheet">
</head>
<body>
@php $user = auth()->user(); @endphp
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <a href="{{ route('dashboard') }}" class="side-brand">
      @include('partials.crest', ['size' => 46])
      <span>University of the Cordilleras<small>Philippines</small></span>
    </a>

    <nav class="side-nav" aria-label="Main">
      <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}"><i class="bi bi-house-door"></i> Dashboard</a>

      @if ($user->role === 'student')
        <a href="{{ route('student.subjects') }}" class="{{ request()->routeIs('student.subjects') ? 'active' : '' }}"><i class="bi bi-journal-bookmark"></i> My Subjects</a>
        <a href="{{ route('student.grades') }}" class="{{ request()->routeIs('student.grades') ? 'active' : '' }}"><i class="bi bi-award"></i> My Grades</a>
      @elseif ($user->role === 'instructor')
        <a href="{{ route('instructor.classes') }}" class="{{ request()->routeIs('instructor.*') ? 'active' : '' }}"><i class="bi bi-easel"></i> My Classes</a>
      @else
        <a href="{{ route('admin.users') }}" class="{{ request()->routeIs('admin.users') ? 'active' : '' }}"><i class="bi bi-people"></i> Users</a>
        <a href="{{ route('admin.subjects') }}" class="{{ request()->routeIs('admin.subjects') ? 'active' : '' }}"><i class="bi bi-journal-text"></i> Subjects</a>
        <a href="{{ route('admin.announcements') }}" class="{{ request()->routeIs('admin.announcements') ? 'active' : '' }}"><i class="bi bi-megaphone"></i> Announcements</a>
      @endif
    </nav>

    <form method="POST" action="{{ route('logout') }}" class="side-foot">
      @csrf
      <button type="submit"><i class="bi bi-box-arrow-left"></i> Log out</button>
    </form>
  </aside>
  <div class="scrim" id="scrim"></div>

  <div class="main">
    <header class="topbar">
      <button class="menu-btn" id="menu" aria-label="Open menu"><i class="bi bi-list"></i></button>
      <h1 class="topbar-title">@yield('heading')</h1>
      <div class="who">
        <div class="who-text"><strong>{{ $user->name }}</strong><small>{{ ucfirst($user->role) }}, {{ $user->school_id }}</small></div>
        <div class="avatar">{{ $user->initial }}</div>
      </div>
    </header>

    <main class="content">
      @include('partials.flash')
      @yield('content')
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const toggle = () => document.body.classList.toggle('nav-open');
  document.getElementById('menu').addEventListener('click', toggle);
  document.getElementById('scrim').addEventListener('click', toggle);
</script>
</body>
</html>
