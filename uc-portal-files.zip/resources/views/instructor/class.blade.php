@extends('layouts.app')
@section('title', $subject->code)
@section('heading', $subject->code . ' ' . $subject->title)

@section('content')
  <p><a href="{{ route('instructor.classes') }}" class="link-uc"><i class="bi bi-arrow-left"></i> Back to My Classes</a></p>

  <section class="panel">
    <h3>Class list and grades</h3>
    @if ($students->isEmpty())
      <p class="empty">No student has enrolled in this class yet.</p>
    @else
      <form method="POST" action="{{ route('instructor.grades', $subject) }}">
        @csrf
        <div class="table-responsive">
          <table class="table table-uc align-middle">
            <thead><tr><th>Student ID</th><th>Name</th><th>Program</th><th style="width:160px">Grade</th></tr></thead>
            <tbody>
            @foreach ($students as $st)
              @php $current = $st->pivot->grade !== null ? number_format($st->pivot->grade, 2) : ''; @endphp
              <tr>
                <td>{{ $st->school_id }}</td><td>{{ $st->name }}</td><td>{{ $st->program }}</td>
                <td>
                  <select name="grades[{{ $st->id }}]" class="form-select form-select-sm">
                    <option value="">No grade yet</option>
                    @foreach ($gradeOptions as $g)<option value="{{ $g }}" @selected($current === $g)>{{ $g }}</option>@endforeach
                  </select>
                </td>
              </tr>
            @endforeach
            </tbody>
          </table>
        </div>
        <button class="btn btn-uc">Save grades</button>
      </form>
    @endif
  </section>
@endsection
