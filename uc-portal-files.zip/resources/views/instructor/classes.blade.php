@extends('layouts.app')
@section('title', 'My Classes')
@section('heading', 'My Classes')

@section('content')
  <section class="panel">
    <h3>Assigned classes</h3>
    @if ($classes->isEmpty())
      <p class="empty">No class is assigned to you yet. Ask the Registrar to assign one.</p>
    @else
      <div class="table-responsive">
        <table class="table table-uc">
          <thead><tr><th>Code</th><th>Subject</th><th>Units</th><th>Schedule</th><th>Room</th><th>Students</th><th></th></tr></thead>
          <tbody>
          @foreach ($classes as $c)
            <tr>
              <td>{{ $c->code }}</td><td>{{ $c->title }}</td><td>{{ $c->units }}</td>
              <td>{{ $c->schedule ?? 'TBA' }}</td><td>{{ $c->room ?? 'TBA' }}</td><td>{{ $c->students_count }}</td>
              <td class="text-end"><a href="{{ route('instructor.class', $c) }}" class="btn btn-uc btn-sm">Open class</a></td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    @endif
  </section>
@endsection
