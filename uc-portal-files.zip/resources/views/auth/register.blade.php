@extends('layouts.guest')
@section('title', 'Create account')

@section('content')
  <h2>Create a student account</h2>
  <p class="muted mb-4">Instructor and administrator accounts are created by the Registrar.</p>

  <form method="POST" action="{{ route('register.store') }}" class="js-loading" novalidate>
    @csrf
    <div class="row g-3">
      <div class="col-sm-6">
        <label for="school_id" class="form-label">Student ID</label>
        <input type="text" id="school_id" name="school_id" value="{{ old('school_id') }}" required
               class="form-control @error('school_id') is-invalid @enderror" placeholder="2023-00123">
        @error('school_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
      <div class="col-sm-6">
        <label for="program" class="form-label">Program</label>
        <select id="program" name="program" required class="form-select @error('program') is-invalid @enderror">
          <option value="" disabled {{ old('program') ? '' : 'selected' }}>Select program</option>
          @foreach ($programs as $p)<option value="{{ $p }}" @selected(old('program') === $p)>{{ $p }}</option>@endforeach
        </select>
        @error('program')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
      <div class="col-12">
        <label for="name" class="form-label">Full name</label>
        <input type="text" id="name" name="name" value="{{ old('name') }}" required class="form-control @error('name') is-invalid @enderror">
        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
      <div class="col-12">
        <label for="email" class="form-label">Email</label>
        <input type="email" id="email" name="email" value="{{ old('email') }}" required class="form-control @error('email') is-invalid @enderror">
        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
      <div class="col-12">
        <label for="password" class="form-label">Password</label>
        <div class="input-group">
          <input type="password" id="password" name="password" required placeholder="At least 8 characters" class="form-control @error('password') is-invalid @enderror">
          <button type="button" class="btn btn-eye" data-target="#password" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
        </div>
        @error('password')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
      </div>
      <div class="col-12">
        <label for="password_confirmation" class="form-label">Confirm password</label>
        <div class="input-group">
          <input type="password" id="password_confirmation" name="password_confirmation" required class="form-control">
          <button type="button" class="btn btn-eye" data-target="#password_confirmation" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
        </div>
      </div>
    </div>

    <div class="captcha"><div class="g-recaptcha" data-sitekey="{{ config('services.recaptcha.site_key') }}"></div></div>
    @error('g-recaptcha-response')<div class="text-danger small text-center mb-2">{{ $message }}</div>@enderror

    <button type="submit" class="btn btn-uc w-100">Create account</button>
  </form>

  <p class="text-center mt-4 muted">Already registered? <a href="{{ route('login') }}" class="link-uc">Log in</a></p>
@endsection
