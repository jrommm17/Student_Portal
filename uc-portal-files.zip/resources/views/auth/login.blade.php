@extends('layouts.guest')
@section('title', 'Log in')

@section('content')
  <h2>Log in</h2>
  <p class="muted mb-4">Use the school ID or email you registered with.</p>

  <form method="POST" action="{{ route('login.store') }}" class="js-loading" novalidate>
    @csrf
    <div class="mb-3">
      <label for="login" class="form-label">School ID or email</label>
      <input type="text" id="login" name="login" value="{{ old('login') }}" autocomplete="username" autofocus required
             class="form-control @error('login') is-invalid @enderror" placeholder="2023-00101 or you@email.com">
      @error('login')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="mb-3">
      <label for="password" class="form-label">Password</label>
      <div class="input-group">
        <input type="password" id="password" name="password" autocomplete="current-password" required
               class="form-control @error('password') is-invalid @enderror">
        <button type="button" class="btn btn-eye" data-target="#password" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
      </div>
      @error('password')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
    </div>

    <div class="form-check mb-2">
      <input class="form-check-input" type="checkbox" name="remember" id="remember">
      <label class="form-check-label" for="remember">Keep me logged in</label>
    </div>

    <div class="captcha"><div class="g-recaptcha" data-sitekey="{{ config('services.recaptcha.site_key') }}"></div></div>
    @error('g-recaptcha-response')<div class="text-danger small text-center mb-2">{{ $message }}</div>@enderror

    <button type="submit" class="btn btn-uc w-100">Log in</button>
  </form>

  <p class="text-center mt-4 muted">New student? <a href="{{ route('register') }}" class="link-uc">Create an account</a></p>

  <details class="demo">
    <summary>Demo accounts</summary>
    <p>Password for all: <code>password123</code></p>
    <ul>
      <li>Student: <code>2023-00101</code></li>
      <li>Instructor: <code>INS-001</code></li>
      <li>Administrator: <code>ADMIN-001</code></li>
    </ul>
  </details>
@endsection
