@extends('layouts.app')
@section('title', 'My Subjects')
@section('heading', 'My Subjects')

@section('content')
  <section class="panel">
    <h3>Enrolled ({{ $enrolled->count() }})</h3>
    @if ($enrolled->isEmpty())
      <p class="empty">You have not enrolled in any subject. Pick one from the list below.</p>
    @else
      <div class="table-responsive">
        <table class="table table-uc">
          <thead><tr><th>Code</th><th>Subject</th><th>Units</th><th>Schedule</th><th>Instructor</th><th></th></tr></thead>
          <tbody>
          @foreach ($enrolled as $s)
            <tr>
              <td>{{ $s->code }}</td><td>{{ $s->title }}</td><td>{{ $s->units }}</td>
              <td>{{ $s->schedule ?? 'TBA' }}</td><td>{{ $s->instructor->name ?? 'Unassigned' }}</td>
              <td class="text-end">
                @if ($s->pivot->grade === null)
                  <form method="POST" action="{{ route('student.drop', $s) }}" onsubmit="return confirm('Drop {{ $s->code }}?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-danger-soft btn-sm">Drop</button>
                  </form>
                @else
                  <small class="muted">Graded</small>
                @endif
              </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    @endif
  </section>

  <section class="panel">
    <h3>Available subjects</h3>
    @if ($available->isEmpty())
      <p class="empty">You are enrolled in every available subject.</p>
    @else
      <div class="table-responsive">
        <table class="table table-uc">
          <thead><tr><th>Code</th><th>Subject</th><th>Units</th><th>Schedule</th><th>Instructor</th><th></th></tr></thead>
          <tbody>
          @foreach ($available as $s)
            <tr>
              <td>{{ $s->code }}</td><td>{{ $s->title }}</td><td>{{ $s->units }}</td>
              <td>{{ $s->schedule ?? 'TBA' }}</td><td>{{ $s->instructor->name ?? 'Unassigned' }}</td>
              <td class="text-end">
                <form method="POST" action="{{ route('student.enroll', $s) }}">@csrf <button class="btn btn-uc btn-sm">Enroll</button></form>
              </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    @endif
  </section>
@endsection
