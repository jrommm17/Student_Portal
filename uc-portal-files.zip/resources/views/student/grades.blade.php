@extends('layouts.app')
@section('title', 'My Grades')
@section('heading', 'My Grades')

@section('content')
  <div class="strip">
    <div><span>General weighted average</span><strong>{{ $gwa ? number_format($gwa, 2) : 'None yet' }}</strong></div>
    <div><span>Scale</span><strong class="small-strong">1.00 highest, 3.00 passing, 5.00 failed</strong></div>
  </div>

  <section class="panel">
    <h3>Grade report</h3>
    @if ($subjects->isEmpty())
      <p class="empty">No grades to show because you are not enrolled in any subject. <a href="{{ route('student.subjects') }}" class="link-uc">Enroll in a subject</a>.</p>
    @else
      <div class="table-responsive">
        <table class="table table-uc">
          <thead><tr><th>Code</th><th>Subject</th><th>Units</th><th>Grade</th><th>Remarks</th></tr></thead>
          <tbody>
          @foreach ($subjects as $s)
            @php $g = $s->pivot->grade; @endphp
            <tr>
              <td>{{ $s->code }}</td><td>{{ $s->title }}</td><td>{{ $s->units }}</td>
              <td>{{ $g !== null ? number_format($g, 2) : 'Not yet posted' }}</td>
              <td>
                @if ($g === null) <span class="tag">Pending</span>
                @elseif ((float) $g <= 3.0) <span class="tag tag-ok">Passed</span>
                @else <span class="tag tag-bad">Failed</span>
                @endif
              </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    @endif
  </section>
@endsection
