<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = ['school_id', 'name', 'email', 'role', 'program', 'password'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return ['password' => 'hashed'];
    }

    public function getInitialAttribute(): string
    {
        return strtoupper(substr($this->name, 0, 1));
    }

    public function subjectsTaught()
    {
        return $this->hasMany(Subject::class, 'instructor_id');
    }

    public function enrolledSubjects()
    {
        return $this->belongsToMany(Subject::class, 'enrollments', 'student_id', 'subject_id')
            ->withPivot('grade')
            ->withTimestamps();
    }

    /** General weighted average (units-weighted); null if no grades yet. */
    public function gwa(): ?float
    {
        $rows = $this->enrolledSubjects()->wherePivotNotNull('grade')->get();
        $units = $rows->sum('units');

        if ($units == 0) {
            return null;
        }

        return $rows->sum(fn ($s) => (float) $s->pivot->grade * $s->units) / $units;
    }
}
