<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Rules\Recaptcha;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class AuthController extends Controller
{
    public const PROGRAMS = ['BSIT', 'BSCS', 'BSCpE', 'BSED', 'BEED', 'BSBA', 'BSA', 'BSN', 'BSCrim', 'BSHM', 'BSTM', 'AB Psychology', 'Other'];

    public function showRegister()
    {
        return view('auth.register', ['programs' => self::PROGRAMS]);
    }

    public function showLogin()
    {
        return view('auth.login');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'school_id' => ['required', 'string', 'max:30', 'unique:users,school_id'],
            'name'      => ['required', 'string', 'max:255'],
            'email'     => ['required', 'email', 'max:255', 'unique:users,email'],
            'program'   => ['required', Rule::in(self::PROGRAMS)],
            'password'  => ['required', 'string', 'min:8', 'confirmed'],
            'g-recaptcha-response' => ['required', new Recaptcha],
        ], [
            'school_id.unique' => 'This Student ID is already registered.',
            'email.unique'     => 'This email is already registered.',
            'g-recaptcha-response.required' => 'Please confirm that you are not a robot.',
        ]);

        User::create([
            'school_id' => $data['school_id'],
            'name'      => $data['name'],
            'email'     => $data['email'],
            'program'   => $data['program'],
            'role'      => 'student', // instructors and admins are created by the administrator
            'password'  => $data['password'], // hashed by the model cast
        ]);

        return redirect()->route('login')->with('status', 'Account created. You can now log in.');
    }

    public function login(Request $request)
    {
        $request->validate([
            'login'    => ['required', 'string'],
            'password' => ['required', 'string'],
            'g-recaptcha-response' => ['required', new Recaptcha],
        ], [
            'login.required' => 'Enter your school ID or email.',
            'g-recaptcha-response.required' => 'Please confirm that you are not a robot.',
        ]);

        $field = filter_var($request->login, FILTER_VALIDATE_EMAIL) ? 'email' : 'school_id';

        if (Auth::attempt([$field => $request->login, 'password' => $request->password], $request->boolean('remember'))) {
            $request->session()->regenerate();

            return redirect()->intended(route('dashboard'));
        }

        return back()->withErrors(['login' => 'Incorrect school ID/email or password.'])->onlyInput('login');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('status', 'You have been logged out.');
    }
}
