<?php

namespace App\Http\Controllers;

use App\Models\Subject;

class StudentController extends Controller
{
    public function subjects()
    {
        $user = auth()->user();
        $enrolled = $user->enrolledSubjects()->with('instructor')->orderBy('code')->get();
        $available = Subject::with('instructor')
            ->whereNotIn('id', $enrolled->pluck('id'))
            ->orderBy('code')->get();

        return view('student.subjects', compact('enrolled', 'available'));
    }

    public function enroll(Subject $subject)
    {
        auth()->user()->enrolledSubjects()->syncWithoutDetaching([$subject->id]);

        return back()->with('status', "You are now enrolled in {$subject->code}.");
    }

    public function drop(Subject $subject)
    {
        $row = auth()->user()->enrolledSubjects()->where('subjects.id', $subject->id)->first();

        if ($row && $row->pivot->grade !== null) {
            return back()->withErrors(['drop' => "{$subject->code} already has a grade and can no longer be dropped."]);
        }

        auth()->user()->enrolledSubjects()->detach($subject->id);

        return back()->with('status', "{$subject->code} was dropped.");
    }

    public function grades()
    {
        $user = auth()->user();

        return view('student.grades', [
            'subjects' => $user->enrolledSubjects()->orderBy('code')->get(),
            'gwa' => $user->gwa(),
        ]);
    }
}
