<?php

namespace App\Http\Controllers;

use App\Models\Subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class InstructorController extends Controller
{
    public const GRADES = ['1.00', '1.25', '1.50', '1.75', '2.00', '2.25', '2.50', '2.75', '3.00', '5.00'];

    public function classes()
    {
        $classes = auth()->user()->subjectsTaught()->withCount('students')->orderBy('code')->get();

        return view('instructor.classes', compact('classes'));
    }

    public function show(Subject $subject)
    {
        $this->authorizeClass($subject);

        return view('instructor.class', [
            'subject' => $subject,
            'students' => $subject->students()->orderBy('name')->get(),
            'gradeOptions' => self::GRADES,
        ]);
    }

    public function saveGrades(Request $request, Subject $subject)
    {
        $this->authorizeClass($subject);

        $request->validate([
            'grades' => ['nullable', 'array'],
            'grades.*' => ['nullable', Rule::in(self::GRADES)],
        ], ['grades.*.in' => 'One of the grades is not on the allowed scale.']);

        foreach ($request->input('grades', []) as $studentId => $grade) {
            DB::table('enrollments')
                ->where('subject_id', $subject->id)
                ->where('student_id', $studentId)
                ->update(['grade' => ($grade === null || $grade === '') ? null : $grade, 'updated_at' => now()]);
        }

        return back()->with('status', 'Grades saved.');
    }

    private function authorizeClass(Subject $subject): void
    {
        abort_unless($subject->instructor_id === auth()->id(), 403, 'This class is not assigned to you.');
    }
}
