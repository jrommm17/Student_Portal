<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $announcements = Announcement::with('author')
            ->whereIn('audience', ['all', $user->role])
            ->latest()->take(5)->get();

        if ($user->role === 'student') {
            return view('dashboard.student', [
                'subjects' => $user->enrolledSubjects()->with('instructor')->orderBy('code')->get(),
                'gwa' => $user->gwa(),
                'announcements' => $announcements,
            ]);
        }

        if ($user->role === 'instructor') {
            $classes = $user->subjectsTaught()->withCount('students')->orderBy('code')->get();

            return view('dashboard.instructor', [
                'classes' => $classes,
                'totalStudents' => $classes->sum('students_count'),
                'announcements' => $announcements,
            ]);
        }

        return view('dashboard.admin', [
            'counts' => [
                'Students' => User::where('role', 'student')->count(),
                'Instructors' => User::where('role', 'instructor')->count(),
                'Subjects' => Subject::count(),
                'Enrollments' => DB::table('enrollments')->count(),
            ],
            'announcements' => $announcements,
        ]);
    }
}
