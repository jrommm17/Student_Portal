<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Subject;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AdminController extends Controller
{
    /* ---------- Users ---------- */
    public function users(Request $request)
    {
        $role = $request->query('role');

        $users = User::when(in_array($role, ['student', 'instructor', 'admin'], true), fn ($q) => $q->where('role', $role))
            ->orderBy('role')->orderBy('name')->get();

        return view('admin.users', ['users' => $users, 'role' => $role, 'programs' => AuthController::PROGRAMS]);
    }

    public function storeUser(Request $request)
    {
        $data = $request->validate([
            'school_id' => ['required', 'string', 'max:30', 'unique:users,school_id'],
            'name'      => ['required', 'string', 'max:255'],
            'email'     => ['required', 'email', 'max:255', 'unique:users,email'],
            'role'      => ['required', Rule::in(['student', 'instructor', 'admin'])],
            'program'   => ['nullable', 'string', 'max:100'],
            'password'  => ['required', 'string', 'min:8'],
        ]);

        User::create($data);

        return back()->with('status', "Account for {$data['name']} was created.");
    }

    public function destroyUser(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->withErrors(['user' => 'You cannot delete your own account.']);
        }

        $user->delete();

        return back()->with('status', 'User deleted.');
    }

    /* ---------- Subjects ---------- */
    public function subjects()
    {
        return view('admin.subjects', [
            'subjects' => Subject::with('instructor')->withCount('students')->orderBy('code')->get(),
            'instructors' => User::where('role', 'instructor')->orderBy('name')->get(),
        ]);
    }

    public function storeSubject(Request $request)
    {
        $data = $request->validate([
            'code'  => ['required', 'string', 'max:20', 'unique:subjects,code'],
            'title' => ['required', 'string', 'max:255'],
            'units' => ['required', 'integer', 'between:1,6'],
            'schedule' => ['nullable', 'string', 'max:100'],
            'room'  => ['nullable', 'string', 'max:50'],
            'instructor_id' => ['nullable', Rule::exists('users', 'id')->where('role', 'instructor')],
        ]);

        Subject::create($data);

        return back()->with('status', "{$data['code']} was added.");
    }

    public function assignInstructor(Request $request, Subject $subject)
    {
        $data = $request->validate([
            'instructor_id' => ['nullable', Rule::exists('users', 'id')->where('role', 'instructor')],
        ]);

        $subject->update(['instructor_id' => $data['instructor_id'] ?? null]);

        return back()->with('status', "Instructor updated for {$subject->code}.");
    }

    public function destroySubject(Subject $subject)
    {
        $subject->delete();

        return back()->with('status', 'Subject deleted.');
    }

    /* ---------- Announcements ---------- */
    public function announcements()
    {
        return view('admin.announcements', ['announcements' => Announcement::with('author')->latest()->get()]);
    }

    public function storeAnnouncement(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'body' => ['required', 'string', 'max:2000'],
            'audience' => ['required', Rule::in(['all', 'student', 'instructor'])],
        ]);

        Announcement::create($data + ['author_id' => auth()->id()]);

        return back()->with('status', 'Announcement posted.');
    }

    public function destroyAnnouncement(Announcement $announcement)
    {
        $announcement->delete();

        return back()->with('status', 'Announcement deleted.');
    }
}
