LOGO
Put the official school logo here as:  public/images/uc-logo.png
(square PNG with transparent background works best, about 300x300).
When this file exists, the portal uses it automatically on the login page
and sidebar. Until then, a simple placeholder crest is shown.
